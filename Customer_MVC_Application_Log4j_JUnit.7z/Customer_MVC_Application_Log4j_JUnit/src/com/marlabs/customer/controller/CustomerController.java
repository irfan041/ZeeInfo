package com.marlabs.customer.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.marlabs.customer.exceptions.CustomerBusinessException;
import com.marlabs.customer.exceptions.CustomerException;
import com.marlabs.customer.model.Customer;
import com.marlabs.customer.service.CustomerService;
import com.marlabs.customer.service.CustomerServiceImpl;

/**
 * Servlet implementation class CustomerController
 */
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerService customerService = null;

	/** The Constant LOG. */
	private static final Logger LOG = Logger
			.getLogger(CustomerController.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustomerController() {
		super();
		customerService = new CustomerServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<Customer> customerList = null;
		RequestDispatcher dispatcher = null;
		LOG.info("From CustomerController doGet Method");
		try {
			String customerCity = request.getParameter("customerCity");
			customerList = customerService.customerList(customerCity);
			Collections.sort(customerList);
			request.setAttribute("customerList", customerList);
			dispatcher = request.getRequestDispatcher("./displayCustomers.jsp");
			dispatcher.forward(request, response);
		} catch (CustomerBusinessException e) {
			String message = e.getMessage();
			LOG.error("Exception Caught In Controller:" + message);
			request.setAttribute("message", message);
			dispatcher = request.getRequestDispatcher("./display.jsp");
			dispatcher.forward(request, response);
		} catch (CustomerException e) {
			String message = e.getMessage();
			LOG.error("Exception Caught In Controller:" + message);
			request.setAttribute("message", message);
			dispatcher = request.getRequestDispatcher("./failure.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		LOG.info("From CustomerController doPost Method");
		int customerId = Integer.parseInt(request.getParameter("customerId"));
		String customerName = request.getParameter("customerName");
		String customerCity = request.getParameter("customerCity");
		String customerMailId = request.getParameter("customerMailId");
		String customerContactNumber = request
				.getParameter("customerContactNumber");
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer.setCustomerName(customerName);
		customer.setCustomerMailId(customerMailId);
		customer.setCustomerCity(customerCity);
		customer.setCustomerContactNumber(customerContactNumber);
		RequestDispatcher dispatcher = null;
		try {
			boolean registrationFlag = customerService.saveCustomer(customer);
			if (registrationFlag) {
				dispatcher = request.getRequestDispatcher("./regSuccess.jsp");
				dispatcher.forward(request, response);
			}
		} catch (CustomerBusinessException e) {
			String message = e.getMessage();
			LOG.error("Exception Caught In Controller:" + message);
			request.setAttribute("message", message);
			dispatcher = request.getRequestDispatcher("./registerCustomer.jsp");
			dispatcher.forward(request, response);
		} catch (CustomerException e) {
			String message = e.getMessage();
			LOG.error("Exception Caught In Controller:" + message);
			request.setAttribute("message", message);
			dispatcher = request.getRequestDispatcher("./failure.jsp");
			dispatcher.forward(request, response);
		}
	}
}
