package com.marlabs.customer.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.marlabs.customer.exceptions.CustomerBusinessException;
import com.marlabs.customer.exceptions.CustomerException;
import com.marlabs.customer.model.Customer;
import com.marlabs.customer.service.CustomerService;
import com.marlabs.customer.service.CustomerServiceImpl;

/**
 * @author srinivasa.challa
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CustomerImplListTest {
	private static CustomerService service;

	/**
	 * 
	 */
	@BeforeClass
	public static void init() {
		service = new CustomerServiceImpl();
	}

	/**
	 * 
	 */
	@AfterClass
	public static void destroy() {
		service = null;
	}

	/**
	 * 
	 */
	@Test
	public void testCustomerList() {
		try {
			List<Customer> cusList = service.customerList("Mysore");
			int size = cusList.size();
			assertEquals(5, size);
		} catch (CustomerBusinessException e) {
			fail();
		} catch (CustomerException e) {
			fail();
		}
	}

	/**
	 * 
	 */
	@Test
	public void testCustomerList1() {
		try {
			Customer customer = new Customer();
			customer.setCustomerId(1);
			customer.setCustomerCity("Mysore");
			customer.setCustomerName("AAA");
			customer.setCustomerMailId("abc@gmail.com");
			customer.setCustomerContactNumber("09703645810");

			Customer customer1 = new Customer();
			customer1.setCustomerId(2);
			customer1.setCustomerCity("Mysore");
			customer1.setCustomerName("AAA");
			customer1.setCustomerMailId("abc@gmail.com");
			customer1.setCustomerContactNumber("09703645810");

			Customer customer2 = new Customer();
			customer2.setCustomerId(3);
			customer2.setCustomerCity("Mysore");
			customer2.setCustomerName("AAA");
			customer2.setCustomerMailId("abc@gmail.com");
			customer2.setCustomerContactNumber("09703645810");
			Customer customer3 = new Customer();
			customer3.setCustomerId(4);
			customer3.setCustomerCity("Mysore");
			customer3.setCustomerName("AAA");
			customer3.setCustomerMailId("abc@gmail.com");
			customer3.setCustomerContactNumber("09703645810");

			Customer customer4 = new Customer();
			customer4.setCustomerId(4);
			customer4.setCustomerCity("Mysore");
			customer4.setCustomerName("AAA");
			customer4.setCustomerMailId("abc@gmail.com");
			customer4.setCustomerContactNumber("09703645810");

			List<Customer> cusListActual = new ArrayList<Customer>();
			cusListActual.add(customer);
			cusListActual.add(customer1);
			cusListActual.add(customer2);
			cusListActual.add(customer3);
			cusListActual.add(customer4);

			List<Customer> cusList = service.customerList("Mysore");

			boolean result = cusList.containsAll(cusListActual);
			assertTrue(result);
			System.out.println(cusListActual);
			System.out.println(cusList);
		} catch (CustomerBusinessException e) {
			fail();
		} catch (CustomerException e) {
			fail();
		}
	}

	/**
	 * 
	 */
	@SuppressWarnings("unused")
	@Test
	public void testCustomerList2() {
		try {
			List<Customer> cusList = service.customerList("Banglore");
		} catch (CustomerBusinessException e) {
			System.out.println(e.getMessage());
		} catch (CustomerException e) {
			fail();
		}
	}
}
