package com.marlabs.customer.test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.marlabs.customer.exceptions.CustomerBusinessException;
import com.marlabs.customer.exceptions.CustomerException;
import com.marlabs.customer.model.Customer;
import com.marlabs.customer.service.CustomerService;
import com.marlabs.customer.service.CustomerServiceImpl;

/**
 * @author srinivasa.challa
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CustomerImplTestSave {
	private static CustomerService service;

	/**
	 * 
	 */
	@BeforeClass
	public static void init() {
		service = new CustomerServiceImpl();
	}

	/**
	 * 
	 */
	@AfterClass
	public static void destroy() {
		service = null;
	}

	/**
	 * 
	 */
	@Test
	public void testSaveCustomer() {

		Customer customer = new Customer();
		try {
			customer.setCustomerId(5);
			customer.setCustomerCity("Mysore");
			customer.setCustomerName("AAA");
			customer.setCustomerMailId("abc@gmail.com");
			customer.setCustomerContactNumber("09703645810");
			boolean result = service.saveCustomer(customer);
			assertTrue(result);
		} catch (CustomerBusinessException e) {
			fail();
		} catch (CustomerException e) {
			fail();
		}
	}

	/**
	 * 
	 */
	@SuppressWarnings("unused")
	@Test
	public void testSaveCustomer1() {
		Customer customer = new Customer();
		try {
			customer.setCustomerId(1);
			customer.setCustomerCity("Mysore");
			customer.setCustomerName("AAA");
			customer.setCustomerMailId("abc@gmail.com");
			customer.setCustomerContactNumber("09703645810");
			boolean result = service.saveCustomer(customer);
		} catch (CustomerBusinessException e) {
			fail();
		} catch (CustomerException e) {
			System.err.println(e.getMessage());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testSaveCustomer2() {
		Customer customer = new Customer();
		try {
			customer.setCustomerId(3);
			customer.setCustomerCity("Mysore");
			customer.setCustomerName("AAA@123");
			customer.setCustomerMailId("abc@gmail.com");
			customer.setCustomerContactNumber("09703645810");
			boolean result = service.saveCustomer(customer);
			assertTrue(result);
		} catch (CustomerBusinessException e) {
			System.err.println(e.getMessage());
		} catch (CustomerException e) {
			fail();
		}
	}

	/**
	 * 
	 */
	@SuppressWarnings("unused")
	@Test
	public void testSaveCustomer3() {

		Customer customer = new Customer();
		try {
			customer.setCustomerId(4);
			customer.setCustomerCity("Mysore@123");
			customer.setCustomerName("AAA");
			customer.setCustomerMailId("abc@gmail.com");
			customer.setCustomerContactNumber("09703645810");
			boolean result = service.saveCustomer(customer);
		} catch (CustomerBusinessException e) {
			System.err.println(e.getMessage());
		} catch (CustomerException e) {
			fail();
		}
	}

}
