package com.marlabs.customer.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * @author srinivasa.challa
 *
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ CustomerImplTestSave.class, CustomerImplListTest.class })
public class TestSuite {

}
