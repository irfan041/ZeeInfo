package com.marlabs.customer.exceptions;

/**
 * @author srinivasa.challa
 *
 */
@SuppressWarnings("serial")
public class CustomerException extends Exception {

	/**
	 * 
	 */
	public CustomerException() {
		super();
	}

	/**
	 * @param message
	 */
	public CustomerException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public CustomerException(Throwable cause) {
		super(cause);
	}
}
