package com.marlabs.customer.exceptions;

/**
 * @author srinivasa.challa
 *
 */
@SuppressWarnings("serial")
public class CustomerBusinessException extends Exception {

	/**
	 * 
	 */
	public CustomerBusinessException() {
		super();
	}

	/**
	 * @param message
	 */
	public CustomerBusinessException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public CustomerBusinessException(Throwable cause) {
		super(cause);
	}

}
