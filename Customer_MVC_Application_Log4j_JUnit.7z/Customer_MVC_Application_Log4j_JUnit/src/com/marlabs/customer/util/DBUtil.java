package com.marlabs.customer.util;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.marlabs.customer.exceptions.CustomerException;

/**
 * @author srinivasa.challa
 *
 */
@SuppressWarnings("deprecation")
public final class DBUtil {
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(DBUtil.class);

	private DBUtil() {

	}

	/**
	 * @return SessionFactory
	 * @throws CustomerException
	 */
	public static SessionFactory getSessionFactory() throws CustomerException {
		final String METHOD_NAME = "getSessionFactory()";
		LOG.info("Method Invoked:" + METHOD_NAME);
		SessionFactory sessionFactory = null;
		Configuration configuration = null;
		try {
			configuration = new AnnotationConfiguration();
			configuration.configure();
			sessionFactory = configuration.buildSessionFactory();
		} catch (HibernateException e) {
			throw new CustomerException(e);
		}
		LOG.info("Response From The Method:" + METHOD_NAME + ":"
				+ sessionFactory);
		return sessionFactory;
	}
}
