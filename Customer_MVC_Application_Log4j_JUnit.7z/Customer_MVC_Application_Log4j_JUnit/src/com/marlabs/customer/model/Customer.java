package com.marlabs.customer.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author srinivasa.challa
 *
 */
@Entity
@Table(name = "CustomerMVC_Table")
@SuppressWarnings("serial")
public class Customer implements Serializable, Comparable<Customer> {
	@Id
	@Column(name = "customerId")
	private int customerId;
	@Column(name = "customerName", nullable = false, length = 30)
	private String customerName;
	@Column(name = "customerCity", nullable = false, length = 30)
	private String customerCity;
	@Column(name = "customerMailId", nullable = false, length = 30)
	private String customerMailId;
	@Column(name = "customerContactNumber", nullable = false, length = 11)
	private String customerContactNumber;

	/**
	 * @return the customerId
	 */
	public int getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName
	 *            the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the customerCity
	 */
	public String getCustomerCity() {
		return customerCity;
	}

	/**
	 * @param customerCity
	 *            the customerCity to set
	 */
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}

	/**
	 * @return the customerMailId
	 */
	public String getCustomerMailId() {
		return customerMailId;
	}

	/**
	 * @param customerMailId
	 *            the customerMailId to set
	 */
	public void setCustomerMailId(String customerMailId) {
		this.customerMailId = customerMailId;
	}

	/**
	 * @return the customerContactNumber
	 */
	public String getCustomerContactNumber() {
		return customerContactNumber;
	}

	/**
	 * @param customerContactNumber
	 *            the customerContactNumber to set
	 */
	public void setCustomerContactNumber(String customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName="
				+ customerName + ", customerCity=" + customerCity
				+ ", customerMailId=" + customerMailId
				+ ", customerContactNumber=" + customerContactNumber + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((customerCity == null) ? 0 : customerCity.hashCode());
		result = prime
				* result
				+ ((customerContactNumber == null) ? 0 : customerContactNumber
						.hashCode());
		result = prime * result + customerId;
		result = prime * result
				+ ((customerMailId == null) ? 0 : customerMailId.hashCode());
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Customer)) {
			return false;
		}
		Customer other = (Customer) obj;
		if (customerCity == null) {
			if (other.customerCity != null) {
				return false;
			}
		} else if (!customerCity.equals(other.customerCity)) {
			return false;
		}
		if (customerContactNumber == null) {
			if (other.customerContactNumber != null) {
				return false;
			}
		} else if (!customerContactNumber.equals(other.customerContactNumber)) {
			return false;
		}
		if (customerId != other.customerId) {
			return false;
		}
		if (customerMailId == null) {
			if (other.customerMailId != null) {
				return false;
			}
		} else if (!customerMailId.equals(other.customerMailId)) {
			return false;
		}
		if (customerName == null) {
			if (other.customerName != null) {
				return false;
			}
		} else if (!customerName.equals(other.customerName)) {
			return false;
		}
		return true;
	}

	public int compareTo(Customer o) {
		return new Integer(this.customerId)
				.compareTo(new Integer(o.customerId));
	}
}
