package com.marlabs.customer.service;

import java.util.List;

import com.marlabs.customer.exceptions.CustomerBusinessException;
import com.marlabs.customer.exceptions.CustomerException;
import com.marlabs.customer.model.Customer;

/**
 * @author srinivasa.challa
 *
 */
public interface CustomerService {

	/**
	 * @param customer
	 * @return boolean
	 * @throws CustomerBusinessException
	 * @throws CustomerException
	 */
	public abstract boolean saveCustomer(final Customer customer)
			throws CustomerBusinessException, CustomerException;

	/**
	 * @param customerCity
	 * @return List<Customer>
	 * @throws CustomerBusinessException
	 * @throws CustomerException
	 */
	public abstract List<Customer> customerList(final String customerCity)
			throws CustomerBusinessException, CustomerException;
}
