package com.marlabs.customer.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.marlabs.customer.exceptions.CustomerBusinessException;
import com.marlabs.customer.model.Customer;

/**
 * @author srinivasa.challa
 *
 */
public class CustomerValidator {
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(CustomerValidator.class);

	/**
	 * @param customer
	 * @return boolean
	 * @throws CustomerBusinessException
	 */
	public static boolean validate(final Customer customer)
			throws CustomerBusinessException {
		final String METHOD_NAME = "validate";
		LOG.info("Method Invoked:" + METHOD_NAME + ":" + customer);
		boolean validationFlag = false;
		if (validateCustomerCity(customer.getCustomerCity())
				&& validateCustomerName(customer.getCustomerName())) {
			validationFlag = true;
		}
		LOG.info("Response From The Method:" + METHOD_NAME + ":"
				+ validationFlag);
		return validationFlag;
	}

	private static boolean validateCustomerName(final String customerName)
			throws CustomerBusinessException {
		final String METHOD_NAME = "validateCustomerName";
		LOG.info("Method Invoked:" + METHOD_NAME + ":" + customerName);
		boolean customerNameFlag = false;
		String pattren = "^[a-zA-Z]+$";
		Pattern myPattren = Pattern.compile(pattren);
		Matcher matcher = myPattren.matcher(customerName);
		if (!matcher.matches()) {
			LOG.debug("if Block In" + METHOD_NAME);
			throw new CustomerBusinessException(
					"Only Characters Allowed For Customer Name");
		} else {
			LOG.debug("Else Block In" + METHOD_NAME);
			customerNameFlag = true;
		}
		LOG.info("Response From The Method:" + METHOD_NAME + ":"
				+ customerNameFlag);
		return customerNameFlag;
	}

	private static boolean validateCustomerCity(final String customerCity)
			throws CustomerBusinessException {
		final String METHOD_NAME = "validateCustomerCity";
		LOG.info("Method Invoked:" + METHOD_NAME + ":" + customerCity);
		boolean customerCityFlag = false;
		String pattren = "^[a-zA-Z]+$";
		Pattern myPattren = Pattern.compile(pattren);
		Matcher matcher = myPattren.matcher(customerCity);
		if (!matcher.matches()) {
			LOG.debug("if Block In" + METHOD_NAME);
			throw new CustomerBusinessException(
					"Only Characters Allowed For Customer City");
		} else {
			LOG.debug("Else Block In" + METHOD_NAME);
			customerCityFlag = true;
		}
		LOG.info("Response From The Method:" + METHOD_NAME + ":"
				+ customerCityFlag);
		return customerCityFlag;
	}

}
