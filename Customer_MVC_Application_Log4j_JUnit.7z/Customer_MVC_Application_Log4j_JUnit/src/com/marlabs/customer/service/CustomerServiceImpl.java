package com.marlabs.customer.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.marlabs.customer.dao.CustomerDAO;
import com.marlabs.customer.dao.CustomerDAOImpl;
import com.marlabs.customer.exceptions.CustomerBusinessException;
import com.marlabs.customer.exceptions.CustomerException;
import com.marlabs.customer.model.Customer;

/**
 * @author srinivasa.challa
 *
 */
public class CustomerServiceImpl implements CustomerService {
	private CustomerDAO customerDao; // HAS A Relation
	/** The Constant LOG. */
	private static final Logger LOG = Logger
			.getLogger(CustomerServiceImpl.class);

	/**
	 * 
	 */
	public CustomerServiceImpl() {
		customerDao = new CustomerDAOImpl();
	}

	public boolean saveCustomer(final Customer customer)
			throws CustomerBusinessException, CustomerException {
		final String METHOD_NAME = "saveCustomer";
		LOG.info("Method Invoked:" + METHOD_NAME + ":" + customer);
		boolean regFlag = false;
		if (CustomerValidator.validate(customer)) {
			regFlag = customerDao.saveCustomer(customer);
		}
		LOG.info("Respponse From The Method:" + METHOD_NAME + ":" + regFlag);
		return regFlag;
	}

	public List<Customer> customerList(final String customerCity)
			throws CustomerBusinessException, CustomerException {
		final String METHOD_NAME = "customerList";
		LOG.info("Method Invoked:" + METHOD_NAME + ":" + customerCity);
		List<Customer> customerList = null;
		customerList = customerDao.customerList(customerCity);
		if (customerList.isEmpty()) {
			throw new CustomerBusinessException(
					"No Customers Found In The Given City");
		}
		LOG.info("Respponse From The Method:" + METHOD_NAME + ":"
				+ customerList);
		return customerList;
	}

}
