package com.marlabs.customer.dao;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.marlabs.customer.exceptions.CustomerException;
import com.marlabs.customer.model.Customer;
import com.marlabs.customer.util.DBUtil;

/**
 * @author srinivasa.challa
 *
 */
public class CustomerDAOImpl implements CustomerDAO {
	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(CustomerDAOImpl.class);

	public boolean saveCustomer(final Customer customer)
			throws CustomerException {
		final String METHOD_NAME = "saveCustomer";
		LOG.info("Method Invoked:" + METHOD_NAME + ":" + customer);
		boolean regFlag = false;
		Session session = null;
		SessionFactory sessionFactory = null;

		try {
			sessionFactory = DBUtil.getSessionFactory();
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			Serializable customerId = session.save(customer);
			LOG.debug(customerId);
			transaction.commit();
			regFlag = true;
		} catch (HibernateException e) {
			throw new CustomerException(e);
		} finally {
			try {
				if (session != null) {
					session.close();
				}
				if (sessionFactory != null) {
					sessionFactory.close();
				}
			} catch (HibernateException e) {
				LOG.fatal(e.getMessage());
			}
		}
		LOG.info("Respponse From The Method:" + METHOD_NAME + ":" + regFlag);
		return regFlag;
	}

	@SuppressWarnings("unchecked")
	public List<Customer> customerList(final String customerCity)
			throws CustomerException {
		final String METHOD_NAME = "customerList";
		LOG.info("Method Invoked:" + METHOD_NAME + ":" + customerCity);
		Session session = null;
		SessionFactory sessionFactory = null;
		List<Customer> customerList = null;
		try {
			sessionFactory = DBUtil.getSessionFactory();
			session = sessionFactory.openSession();
			Query query = session
					.createQuery("FROM Customer WHERE customerCity=?");
			query.setParameter(0, customerCity);
			customerList = query.list();
		} catch (HibernateException e) {
			throw new CustomerException(e);
		} finally {
			try {
				if (session != null) {
					session.close();
				}
				if (sessionFactory != null) {
					sessionFactory.close();
				}
			} catch (HibernateException e) {
				LOG.fatal(e.getMessage());
			}
		}
		LOG.info("Respponse From The Method:" + METHOD_NAME + ":"
				+ customerList);
		return customerList;
	}
}
