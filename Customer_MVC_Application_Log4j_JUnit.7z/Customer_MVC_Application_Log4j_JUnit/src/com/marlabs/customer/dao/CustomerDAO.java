package com.marlabs.customer.dao;

import java.util.List;

import com.marlabs.customer.exceptions.CustomerException;
import com.marlabs.customer.model.Customer;

/**
 * @author srinivasa.challa
 *
 */
public interface CustomerDAO {
	/**
	 * @param customer
	 * @return boolean
	 * @throws CustomerException
	 */
	public abstract boolean saveCustomer(final Customer customer)
			throws CustomerException;

	/**
	 * @param cutomerCity
	 * @return List<Customer>
	 * @throws CustomerException
	 */
	public abstract List<Customer> customerList(final String cutomerCity)
			throws CustomerException;
}
